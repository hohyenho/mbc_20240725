import React from 'react'

const Skip = () => {
    return (
        <div id='skip'>
            <a href="#">헤더영역</a>
            <a href="#">인트로영역</a>
            <a href="#">스틸영역</a>
            <a href="#">사이트영역</a>
            <a href="#">포토폴리오영역</a>
            <a href="#">연락처영역</a>
        </div>
    )
}

export default Skip
